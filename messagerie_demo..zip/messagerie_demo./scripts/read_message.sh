#!/usr/bin/env bash
set -euo pipefail

if [ $# -ne 3 ]; then
  echo "Usage: $0 <recipient> <sender> <encrypted_file>" >&2
  exit 1
fi

RECIP="$1"
SENDER="$2"
ENCRYPTED_FILE="$3"
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
GNUPGHOME="$BASE_DIR/gnupg"
export GNUPGHOME
USER_DIR="$BASE_DIR/utilisateurs"
OUT_SIG="$BASE_DIR/messages/decrypted.sig"

openssl cms -decrypt -inform PEM       -in "$ENCRYPTED_FILE"       -recip "$USER_DIR/$RECIP/$RECIP.cert.pem"       -inkey "$USER_DIR/$RECIP/$RECIP.key.pem"       -out "$OUT_SIG"

echo "── Vérification & contenu ──"
gpg --decrypt "$OUT_SIG"
