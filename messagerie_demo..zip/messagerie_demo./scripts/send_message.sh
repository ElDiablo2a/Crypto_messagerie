#!/usr/bin/env bash
set -euo pipefail

if [ $# -ne 2 ]; then
  echo "Usage: $0 <sender> <recipient>" >&2
  exit 1
fi

SENDER="$1"
RECIP="$2"
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
GNUPGHOME="$BASE_DIR/gnupg"
export GNUPGHOME
USER_DIR="$BASE_DIR/utilisateurs"
MSG_DIR="$BASE_DIR/messages"

TIMESTAMP=$(date +%Y%m%d%H%M%S)
PLAINTEXT="$MSG_DIR/msg-${SENDER}-to-${RECIP}-${TIMESTAMP}.txt"
SIGNED="$MSG_DIR/msg-${SENDER}-to-${RECIP}-${TIMESTAMP}.sig"
ENCRYPTED="$MSG_DIR/msg-${SENDER}-to-${RECIP}-${TIMESTAMP}.enc"

echo "Entrez votre message, puis Ctrl-D :"
cat > "$PLAINTEXT"

# signer
gpg --batch --yes --default-key "$SENDER" --output "$SIGNED" --sign "$PLAINTEXT"

# chiffrer
openssl cms -encrypt -binary -aes256 -outform PEM       -in "$SIGNED" -out "$ENCRYPTED"       "$USER_DIR/$RECIP/$RECIP.cert.pem"

echo "Message chiffré créé : $ENCRYPTED"
