#!/usr/bin/env bash
set -euo pipefail

if [ $# -ne 1 ]; then
  echo "Usage: $0 <username>" >&2
  exit 1
fi

USER_NAME="$1"
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CA_DIR="$BASE_DIR/ca"
USER_DIR="$BASE_DIR/utilisateurs/$USER_NAME"
GNUPGHOME="$BASE_DIR/gnupg"
export GNUPGHOME

mkdir -p "$USER_DIR"

# 1. Génération paire GPG
gpg --batch --gen-key <<EOF
%no-protection
Key-Type: RSA
Key-Length: 2048
Name-Real: $USER_NAME
Name-Email: $USER_NAME@example.com
Expire-Date: 0
%commit
EOF

# Export clé publique
gpg --armor --export "$USER_NAME" > "$USER_DIR/$USER_NAME-gpg-pub.asc"

# 2. Génération clé privée OpenSSL
openssl genrsa -out "$USER_DIR/$USER_NAME.key.pem" 2048

# 3. CSR
openssl req -new -key "$USER_DIR/$USER_NAME.key.pem"       -out "$USER_DIR/$USER_NAME.csr.pem"       -subj "/C=FR/ST=IDF/L=Paris/O=Messagerie/CN=$USER_NAME"

# 4. Signature CSR par la CA
openssl x509 -req       -in "$USER_DIR/$USER_NAME.csr.pem"       -CA "$CA_DIR/ca.cert.pem"       -CAkey "$CA_DIR/ca.key.pem"       -CAcreateserial       -out "$USER_DIR/$USER_NAME.cert.pem"       -days 365       -sha256

echo "Utilisateur $USER_NAME créé dans $USER_DIR"
