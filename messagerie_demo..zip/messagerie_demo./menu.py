#!/usr/bin/env python3
import subprocess
import sys
import os

# 1) Chemin du fichier courant
HERE = os.path.dirname(os.path.abspath(__file__))

# 2) Si ce script est dans "scripts/", on remonte d’un cran ;
#    sinon, on reste dans le même dossier.
if os.path.basename(HERE) == "scripts":
    BASE_DIR = os.path.dirname(HERE)
else:
    BASE_DIR = HERE

SCRIPTS_DIR = os.path.join(BASE_DIR, "scripts")

def run_script(script, *args):
    path = os.path.join(SCRIPTS_DIR, script)
    if not os.path.isfile(path):
        print(f"Erreur : script introuvable : {path}")
        return
    subprocess.run([path] + list(args), check=True)

def create_user():
    name = input("Nom d'utilisateur à créer : ").strip()
    if name:
        run_script("create_user.sh", name)

def send_message():
    sender = input("Expéditeur (ex: alice) : ").strip()
    recip  = input("Destinataire (ex: bob) : ").strip()
    if sender and recip:
        run_script("send_message.sh", sender, recip)

def read_message():
    recip  = input("Destinataire (qui lit) : ").strip()
    sender = input("Expéditeur (qui a signé) : ").strip()
    file   = input("Chemin vers le fichier chiffré : ").strip()
    if recip and sender and file:
        run_script("read_message.sh", recip, sender, file)

def main():
    options = {
        "1": ("Créer un utilisateur", create_user),
        "2": ("Envoyer un message",   send_message),
        "3": ("Lire un message",      read_message),
        "q": ("Quitter",              sys.exit),
    }
    while True:
        print("\n=== Menu Messagerie Sécurisée ===")
        for key, (desc, _) in options.items():
            print(f" {key} → {desc}")
        choice = input("Choisissez une option : ").strip()
        action = options.get(choice)
        if action:
            action[1]()
        else:
            print("Option invalide, réessayez.")

if __name__ == "__main__":
    main()

